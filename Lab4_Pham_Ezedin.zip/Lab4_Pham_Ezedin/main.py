"""
Evan Pham and Rayan Ezedin
9/17/24
"""
import random


def main():

    while True:

        print('Treasure Hunt!\nFind the 7 treasures without getting caught in a trap. Look around to spot nearby traps and treasures.')
        map_data = read_map()
        map_user = [["." for i in range(7)] for j in range(7)] #creates the map the user sees

        player_pos = [0, 0] #starts the user at (0,0)

        treasures_found = 0
        total_treasures = 7

        while True:

            display_map(map_user, player_pos) #display the map

            #asks user to choose where they want to travel 
            user_action = input("Enter Direction: (WASD or L to look around or Q to quit): ").upper()

            if user_action == "Q": #Quit if user chooses to quit
                break

            elif user_action == "L": #Look around for treasures
                treasures_traps = count_treasures_traps(map_data, player_pos, 6)
                print("You detect " + str(treasures_traps[0]) + " treasures nearby")
                print("You detect " + str(treasures_traps[1]) + " traps nearby")

                if not map_user[player_pos[1]][player_pos[0]] == "T": #If standing on treasure, doesn't replace it with a number
                    map_user[player_pos[1]][player_pos[0]] = treasures_traps[1] 

            else: 
                move_player(player_pos, user_action, 6) #move player 

                if map_user[player_pos[1]][player_pos[0]] == "T": #If already found treasure
                    print('You already found that treasure!')

                elif map_data[player_pos[1]][player_pos[0]] == "T": #If on treasure
                    print("You found treasure!")

                    map_user[player_pos[1]][player_pos[0]] = "T" #update the user's map
                    treasures_found += 1
                
                if map_data[player_pos[1]][player_pos[0]] == "X": #If on trap
                    print('You were caught in a trap!')

                    print('You found ' + str(treasures_found) + ' treasures')
                    break

            if total_treasures == treasures_found: #game ends when user finds all of the treasures
                print("Congratulations! You found all of the treasures!")
                break

        #Keeps player in loop until they quit
        again = True

        while again == True:

            go_again = input('Play again? (Y/N)').upper()

            if go_again == "N":
                again = False

            elif go_again == "Y":
                break

            else:
                print("Invalid Answer. Play again? (Y/N)")

        if again == False:
            break
        

def read_map():
    """
    Takes the file 'map.txt' and reads it, line by line.
    Args:
        None
    Return:
        A 7x7 2d list consisting of the contents of all the lines in 'map.txt'
    """

    map_data = []

    with open('map.txt', 'r') as file:
        for line in file:
            cleared_line = line.split()
            map_data.append(cleared_line)

    return map_data


def display_map(map, player):
    """
    Display the map the user sees.
    Args:
        map: The 2d list representing the map the user sees.
        player: A list representing the player's coordinates.
    Return:
        None
    """
    
    rows = len(map)
    cols = len(map[0])
    
    for row in range(rows):
        for col in range(cols):    
            if row == player[1] and col == player[0]:
                print('P', end = ' ') #displays where the user is located
            else:
                print(map[row][col], end = ' ') #presents character to user
        print() #creates a new line after each row 


def move_player(player, dir, upper_bound):
    """
    Move the player 1 position left/right/up/down on the map
    Args:
        player: A list representing the player's coordinates.
        dir: A char representing what direction to move.
        upper_bound: An int, 6, which represents the upper bound of the map
    Return:
        None
    """

    #move the player
    if dir == 'W':
        if player[1] == 0:
            print('Cannot move that direction')
        else:
            player[1] -= 1 #move player up
            
    elif dir == 'A':
        if player[0] == 0:
            print('Cannot move that direction')
        else:
            player[0] -= 1 #move player left

    elif dir == 'S':
        if player[1] == upper_bound:
            print('Cannot move that direction')
        else:
            player[1] += 1 #move player down

    elif dir == 'D':
        if player[0] == upper_bound:
            print('Cannot move that direction')
        else:
            player[0] += 1 #move player right

    else:
        print('Invalid input')


def count_treasures_traps(map, player, upper_bound=6):
    """
    Count all the treasures and traps nearby the player.
    Args:
        map: The 2d list representing the game map.
        player: A list representing the player's coordinates.
        upper_bound: An int, 6, which represents the upper bound of the map
    Return:
        Returns a list containing the number of treasures and traps
    """

    col = player[0]
    row = player[1]
    treasures = 0
    traps = 0    
    
    #check tile player is standing on
    if map[row][col] == "T":
        treasures += 1


    #check the tile 1 right of the player
    if col + 1 <= upper_bound: #if player's col is within bounds, you can check the tile

        if map[row][col + 1] == "T":
            treasures += 1

        if map[row][col + 1] == "X":
            traps += 1
    

    #check the tile 1 right 1 up of the player
    if col + 1 <= upper_bound and row - 1 >= 0:
        
        if map[row - 1][col + 1] == "T":
            treasures += 1

        if map[row - 1][col + 1] == "X":
            traps += 1


    #check the tile 1 right 1 down of the player
    if col + 1 <= upper_bound and row + 1 <= upper_bound:

        if map[row + 1][col + 1] == "T":
            treasures += 1

        if map[row + 1][col + 1] == "X":
            traps += 1
            

    #check the tile 1 left of the player
    if col - 1 >= 0:

        if map[row][col  - 1] == "T":
            treasures += 1
        
        if map[row][col - 1] == "X":
            traps += 1
            
    
    #check the tile 1 left 1 up of the player
    if col - 1 >= 0 and row - 1 >= 0:

        if map[row - 1][col - 1] == "T":
            treasures += 1

        if map[row - 1][col - 1] == "X":
            traps += 1
    

    #check the tile 1 left 1 down of the player
    if col - 1 >= 0 and row + 1 <= upper_bound:
        
        if map[row + 1][col - 1] == "T":
            treasures += 1
        
        if map[row + 1][col - 1] == "X":
            traps += 1

        
    #check the tile 1 down of the player
    if row + 1 <= upper_bound:

        if map[row + 1][col] == "T":
            treasures += 1

        if map[row + 1][col] == "X":
            traps += 1


    #check the tile 1 up of the player
    if row - 1 >= 0:

        if map[row - 1][col] == "T":
            treasures += 1

        if map[row - 1][col] == "X":
            traps += 1  

    return [treasures, traps]



main()